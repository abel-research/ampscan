# -*- coding: utf-8 -*-
"""
Created on Thu Sep 14 13:22:29 2017

@author: js22g12
"""

import numpy as np
import pandas as pd

class trimMixin(object):
    """
    docstring

    """
    
    def planarTrim(self):
        print('This is where the planar trim function will go')